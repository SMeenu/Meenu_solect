/**
 * @Copyright (c) 2016 by Solectria, A Yaskawa Company.  All rights reserved.
 * @name testarch.js
 * @author fengjia hu
 * @module -- 
 * @description   YS side code to test arches communication
 */

"use strict";

// Following  are the packages for DSP communication
var modbusrtu = require('modbus-rtu');
var Q = require('q');
var fs = require('fs');
//var Buffer = require('buffer');
var count = 0;
// 
// load configurations
//
const TEST_ARCHES_CONFIG = './testarches.json';
var testarches_config = JSON.parse(fs.readFileSync(TEST_ARCHES_CONFIG));

// 
// create log file
//
var log4js = require('log4js');
log4js.configure({
    appenders: [
        {
            type: 'file', filename: 'testarches.log', "maxLogSize": 32000,
            "backups": 2, category: 'testarches'
        }
    ]
});
log4js.loadAppender('file');

var logger = log4js.getLogger('testarches');
logger.setLevel('INFO');

// Arches communication object
var ArchesComm = null;
var dsp_dev = '/dev/ttyACM';

// find the USB serial port
for (var i = 0; i < 3; i++) {
    var tmp = dsp_dev + i.toString();
    console.log(tmp);
    try {
        fs.accessSync(tmp);
        dsp_dev = tmp;
        break;
    } catch (err) {
        //console.log('no device:'+ tmp)
    }
}

//dsp_dev = '/dev/ttymxc2';
function ReadDSPRegister(maddr, quant) {
    var deferred = Q.defer();
    
    testarches_config = JSON.parse(fs.readFileSync(TEST_ARCHES_CONFIG));
      
    //var cmd = new Buffer([0x02, 0x01, 0x10, 0x00, 0x8, 0xce, 0x00, 0x00, 0x01, 0x00, 0x27, 0x00, 0xef, 0xcd, 0xef, 0xcd]);
    //var cmd = new Buffer([1, 3, 156, 67, 0, 1, 91, 142]); // READ 40003, 1 word
    var cmd = new Buffer(testarches_config.cmd);
        
   
    
    ArchesComm.readdsp(cmd).then(function (data) { 
        
        if (0 === data.length) { // error
            logger.info('error');
            deferred.reject();
        }
        else {
            deferred.resolve(data);
        }
 
    });
    return deferred.promise;
}

var dspError = function (error) {
    logger.info(error);
}

var testwritedsp = function () {
    const buf = new Buffer(8);
    buf.writeInt16BE(0x2, 0);
    buf.writeInt16BE(0x3, 2);

    ArchesComm.writedsp(9, buf).then(function (data) {
 
            //console.info('DSP reply:' + data); // data = [ ]
            deferred.resolve(data);

    }, function (err) {
        console.info('readdsp.err: ' + err)
        deferred.reject();
    });
}

var routineTasks = function () {
    var readQ = [];
    readQ.push({
        addr: 30556,
        quant: 16
    });
    
    /*
    readQ.push({
        addr: 40001,
        quant: 50
    });
    readQ.push({
        addr: 40070,
        quant: 10
    });
    */

    var promise_chain  = Q.fcall(function () { });
    readQ.forEach(function (rdata) {
        var promise_link = function () {
            //console.info('Send request:' + rdata.addr + ", " + rdata.quant);
            var deferred = Q.defer();
            
            testarches_config = JSON.parse(fs.readFileSync(TEST_ARCHES_CONFIG));
            var cmd = new Buffer(testarches_config.cmd);
            
            console.info('cmd:' + cmd.toString('hex'))

            ArchesComm.readdsp(cmd).then( function (data) { 
                //console.info('rece reply:' + rdata.addr + ", " + rdata.quant);
                
                if (0 === data.length) { // error
                    logger.info('error');
                    deferred.reject();
                }
                else {
                    //console.info('DSP reply:' + data); // data = [ ]
                    deferred.resolve(data);
                }
            }, function (err) {
                console.info('readdsp.err: ' + err)
                deferred.reject();
            });
            
            return deferred.promise;
        };

        promise_chain = promise_chain.then(promise_link);
    });

    return promise_chain;
}

process.on("SIGTERM", function () {
    logger.info('Exit');

    process.exit();
});

// DSP communication
ArchesComm = new modbusrtu.Arches(dsp_dev, function (dsp) {
    
});

var test = function () {
    //routineTasks().then(function () { console.info('done') });
    routineTasks().then(function () {
        //console.info('then');
        //setTimeout(test, 1000);
    }, 
    function () {
        //console.info('then reject');
    }).done(function () {
        count++;
        //console.info('done:'+ count);
        //setTimeout(test, 100);
    }, function (err) {
        //console.info('error:' + count);
        //setTimeout(test, 100);
    });
    //console.info('end of test func')
}
// set routine tasks handler
setTimeout(test, 10);
//setInterval(test, 5000);

//testwritedsp();
