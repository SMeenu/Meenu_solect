ls
mkdir aaaa
echo "Doing good!"
