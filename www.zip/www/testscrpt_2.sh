function clean_up() {
	rm -r /home/service/logs
	# f_tout 'nohup iperf -s &' 8
	rm status
	exit 0
}

# Array stores the parameter string and calculated value in subsequent positions                                                    
arr=
# Array index
count=0
# read choice
choice=$1
if [ $choice != "1" ] && [ $choice != "2" ]; then
	echo "Input not recognized! terminating..." 
	exit 1
fi

# For each neighbor identified:
for ip in $(cat  /home/service/logs/f1); do
ping -c4 $ip >  /home/service/logs/f2
if [ $? -ne 0 ]; then 
	continue; 
fi 
arr[$count]="IPaddr" && ((count++))

# Loss estimate:
arr[$count]="$ip" && ((count++))
arr[count]="Loss" && ((count++)) 
arr[count]=$(grep 'received' /home/service/logs/f2 |awk -F "," 'match($0,/packet loss/) {print substr($0, RSTART-4, 3)}' |sed -e "s/^00/100/" |sed 's/.$//') && ((count++))

# print the average latency in ms:                                           
arr[count]="Latency" && ((count++))
arr[count]=$(cat  /home/service/logs/f2 | grep 'rtt' | awk -F ' ' '{print $4}' | awk -F '/' '{print $2}') && ((count++))

if [ $choice == "1" ]; then
	continue; 
else
#Initializing temporary array to store the iperf output strings
y=                                                                              
i=0;     
# To break the loop if iperf fails 
arr[count]="Upload"  && ((count++))
iperf -c $ip -d > /home/service/logs/f3 2> /home/service/logs/ferr
#f_tout 'iperf -c $ip -d' 26 1> /home/service/logs/f3 2> /home/service/logs/ferr
 if (grep "failed" /home/service/logs/ferr) ; then
 arr_tmp=(" - " "Download" " - ")
 arr=("${arr[@]}" "${arr_tmp[@]}")
 count=$((count+3))
 continue;
 continue
fi

# Computing upload throughput in kbps
upload_unit=$(cat /home/service/logs/f3 |grep "bits/sec"|awk 'NR==1 {print $NF}')
upload_kbps="$(cat /home/service/logs/f3 |grep "bits/sec"|awk 'NR==1 {print $(NF-1)}')"
if [ $upload_unit == "Mbits/sec" ]; then 
arr[count]=$( echo "$upload_kbps * 1000"|bc ) && ((count++))
else 
arr[count]=$upload_kbps  && ((count++))
fi

# Computing download throughput in kbps
arr[count]="Download" && ((count++))
# arr[count]="$(tail -1 /home/service/logs/f3 | awk -F ' ' '{print $(NF-1)$NF}')" && ((count++))

dnload_unit="$(tail -1 /home/service/logs/f3 | awk -F ' ' '{print $NF}')"
dnload_kbps="$(tail -1 /home/service/logs/f3 | awk -F ' ' '{print $(NF-1)}')"
if [ $dnload_unit == "Mbits/sec" ]; then 
arr[count]=$( echo "$dnload_kbps * 1000"|bc ) && ((count++))
else 
arr[count]=$dnload_kbps  && ((count++))
fi
fi
done 

# ==================
# Output formatting:
# ==================

width=43
vars=(${arr[@]})
len=${#arr[@]}

if [ $choice == "1" ]; then
	(header="\n %-15s |%-12s |%-12s\n"                                 
	format=" %-15s |%-12s |%-12s\n"


	printf "$header" "IPaddr" "Loss" "Latency"
	printf "%$width.${width}s\n"
	for (( i=0; i <${#arr[@]}; i=i+6)); do
        	printf "$format" ${arr[$i+1]} ${arr[$i+3]} ${arr[$i+5]}
	done) > perf_result
elif [ $choice == "2" ]; then 
	(header="\n %-15s |%-12s |%-12s |%-16s |%-16s\n"                                 
	format=" %-15s |%-12s |%-12s |%-16s |%-16s\n"                                   
	printf "$header" "IPaddr" "Loss" "Latency" "Upload" "Download"
	printf "%$width.${width}s\n"
	for (( i=0; i <${#arr[@]}; i=i+10)); do
        	printf "$format" ${arr[$i+1]} ${arr[$i+3]} "${arr[$i+5]}" "${arr[$i+7]}" "${arr[$i+9]}"
	done) > perf_result
fi
	# Generation of Nw_perf.json file

	(printf "\n{\"network\": {\n\t \"mesh\":{\n\t\t \"performance\":[\n"
	for (( i=0; i<$len; i+=2 )); do
		if (( $i == 0 )); then
			printf "\t\t{"
		fi                                                                       
    		printf "\"${arr[i]}\": \"${vars[i+1]}\""
		j=$((i+2))
		if [ $choice == "1" ] && (( $j % 6 == 0 && $i < $((len-2)) )); then
			 printf "},\n\t\t{"
        	elif [ $choice == "2" ] && (( $j % 10 == 0 && $i < $((len-2)) ));  then
			printf "},\n\t\t{"
		elif (( $i == $((len-2)) )); then
        	        printf "} \n \t\t\t]\n\t\t}\n\t}\n"
		elif [ $i -lt $((len-2)) ] ; then
		        printf ","
		fi
	done                                                                            
	printf "}\n") > Nw_perf.json          
echo "Completed" > status
clean_up 2>&1 /dev/null
cat Nw_perf.json
