// JavaScript source code
// 2d network graph

var app = angular.module('networkApp', []);

app.controller("networkCtrl", function ($scope, $http, $timeout, $window, $location) {
    $scope.jsonData = null;
    $scope.network = null;
    $scope.nodes = null;
    $scope.edges = null;

    var container = document.getElementById('network2Dgraph');
    var options = {
        interaction: { selectConnectedEdges: false } ,
        layout: { randomSeed: 1 } ,
        edges: {
            selfReferenceSize: 0,
            smooth: true,
            arrows: { to : false }
        }
    };
    var TIME_OUT = 10000;
    
    // handles double click event
    $scope.doubleClick = function (params) {
        if (params.nodes.length > 0) {
            //$http.get("/request-exchange").

            var url = $location.protocol() + "://" + params.nodes[0] + ":" + $location.port() + "/exchange?userid=admin";
            //var url = $location.protocol() + "://" + '169.254.0.10' + ":" + $location.port() + "/exchange?userid=admin";
            console.log('doubleClick Event:', url);
            $window.location.href = url;
        }
   }

    // function to update a displayed 2D graph with latest edges info
    $scope.update = function () {
        $http.get("/networkedges").
            then(function (response) {
            console.log('2D graph update');
            //var update_edges = new vis.DataSet(response.data.edges);
            //$scope.edges.update(update_edges);
            $scope.edges = new vis.DataSet(response.data);

            var data = {
                nodes: $scope.nodes,
                edges: $scope.edges
            };
            
            $scope.network.destroy();
            
            $scope.network = new vis.Network(container, data, options);
            $scope.network.on("doubleClick", function (params) {
                $scope.doubleClick(params);
            });

            //$scope.network.setData(data);
            // set timer 
            $timeout($scope.update, TIME_OUT);
        });
    }

    $scope.init = function () {
        $http.get("/network_map").
            then(function (response) {
            $scope.jsonData = response.data;
            
            // create an array with nodes
            $scope.nodes = new vis.DataSet(response.data.nodes);
            
            // create an array with edges
            $scope.edges = new vis.DataSet(response.data.edges);
            
            // create a network
            var data = {
                nodes: $scope.nodes,
                edges: $scope.edges
            };
            
            $scope.network = new vis.Network(container, data, options);
            
            $scope.network.on("showPopup", function (params) {
                //document.getElementById('eventSpan').innerHTML = '<h2>showPopup event: </h2>' + JSON.stringify(params, null, 4);
            });
            $scope.network.on("hidePopup", function () {
                //console.log('hidePopup Event');
            });
            $scope.network.on("hoverNode", function (params) {
                //console.log('hoverNode Event:', params);
            });
            $scope.network.on("hoverEdge", function (params) {
                //console.log('hoverEdge Event:', params);
            });
            $scope.network.on("blurNode", function (params) {
                //console.log('blurNode Event:', params);
            });
            $scope.network.on("doubleClick", function (params) {
                $scope.doubleClick(params);
            });
            
            // set timer 
            $timeout($scope.update, TIME_OUT);
        });
    };

    // initalize the jsonData object by calling init() function
    $scope.init();
});