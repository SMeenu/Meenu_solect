// JavaScript source code
//var app = angular.module("saveTextApp", []);

var app = angular.module('npJsonEditorApp', ['json-tree']);

app.controller("npJsonEditorCtrl", function ($scope, $http) {
    $scope.jsonData = {};

    $scope.reset = function () {
        $http.get("/getnetworkparams").
            then(function (response) {
                //$scope.jsonData = angular.toJson(response.data);
                $scope.jsonData = response.data;
            }, function (response) {
            console.log("response.fail");
            });
    };
    
    // initalize the jsonData object by calling reset()
    $scope.reset();

    // save JSON object
    $scope.save = function () {
        var jdata = 'params=' + angular.toJson($scope.jsonData, true); // true flag to make it pretty

        // using jQuery
        if (confirm('Are you sure you want to apply the changes?')) {
            $.post("/savenetworkparams", jdata,
		    function (data, status) {
		//alert("Data:" + data + "\nStatus:" + status);
            }); // .post
        } // if
    };

    $scope.save_ng = function () {
        //var dataObj = 'params=' + angular.toJson($scope.jsonData);
        var dataObj = {
            msg: "something",
            data: 123,
            name: " json"
        };
        alert(dataObj);
        
        // dataObj doesn't work, failed to pass dataObj to the server
        $http.post('/savenetworkparams', dataObj).
        then(function (data) {
            console.log(data);
        } , function (response) {
            alert("Error: " + response);
        });
    };

    //$scope.jsonData = { "net": [{ "interface": "eth0", "ip": "dhcp", "netmask": "255.255.255.0", "disabled": "0" }] };
});
