//app.controller("networkCtrl", function ($scope, $http, $timeout, $window, $location) {
var container = document.getElementById('perfToolPlots');

var items = [
    {x: '2014-06-11', y: 10},
    {x: '2014-06-12', y: 25},
    {x: '2014-06-13', y: 30},
    {x: '2014-06-14', y: 10},
    {x: '2014-06-15', y: 15},
    {x: '2014-06-16', y: 30}
  ];

  var dataset = new vis.DataSet(items);
  var options = {
    start: '2014-06-10',
    end: '2014-06-18'
  };
  var graph2d = new vis.Graph2d(container, dataset, options);

/*
//app.controller("networkCtrl", function ($scope, $http, $timeout, $window, $location) {
	var container = document.getElementById('perfToolPlots');

			$scope.init = function () {
			$http.get("/network_test").
            then(function (response) {
		var data = {
				x: response.data.id,
				y: response.data.latency
			};
			alert("X  is:"+ x);
			alert("going to plot");
			var dataset = new vis.DataSet(data);
			var graph2d = new vis.Graph2d(container, dataset);
    };

    // initalize the jsonData object by calling init() function
    $scope.init();
*/
/* var app = angular.module('perfApp', []);
var container = document.getElementById('perfToolPlots');
var items = [
    {x: '2014-06-11', y: 10},
    {x: '2014-06-12', y: 25},
    {x: '2014-06-13', y: 30},
    {x: '2014-06-14', y: 10},
    {x: '2014-06-15', y: 15},
    {x: '2014-06-16', y: 30}
  ];

  var dataset = new vis.DataSet(items);
  var options = {
    start: '2014-06-10',
    end: '2014-06-18'
  };
  var graph2d = new vis.Graph2d(container, dataset, options);
*/
