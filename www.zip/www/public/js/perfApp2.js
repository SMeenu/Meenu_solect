var app = angular.module('perfApp', []);

//app.controller("networkCtrl", function ($scope, $http, $timeout, $window, $location) {
app.controller("perfCtrl", function ($scope, $http, $window, $location) {
    $scope.jsonData = null;
    $scope.nodes = null;
	$scope.latency = null;
	$scope.loss = null;
	$scope.up_throput = null;
	$scope.dn_throput = null;
	$scope.graph2d = null;
    //var container = document.getElementById('network2Dgraph');
	var container = document.getElementById('perfToolPlots');
	
            //var data = {
            //    nodes: $scope.nodes
            // };
			$scope.init = function () {
			$http.get("/network_test").
            then(function (response) {
            $scope.jsonData = response.data;
            
            // create an array with nodes
            $scope.nodes = new vis.DataSet(response.data.id);
            
            // create individual arrays with parameters
            $scope.latency = new vis.DataSet(response.data.latency);
            $scope.loss = new vis.DataSet(response.data.loss);
			$scope.up_throput = new vis.DataSet(response.data.upload);
			$scope.dn_throput = new vis.DataSet(response.data.download);
            $scope.graph2d = new vis.Graph2d(container, dataset, options);
			var data = {
				x: $scope.nodes,
				y: $scope.latency
			};
			alert("going to plot");
			var graph2d = new vis.Graph2d(container, data);
    };

    // initalize the jsonData object by calling init() function
    $scope.init();

/* var app = angular.module('perfApp', []);
var container = document.getElementById('perfToolPlots');
var items = [
    {x: '2014-06-11', y: 10},
    {x: '2014-06-12', y: 25},
    {x: '2014-06-13', y: 30},
    {x: '2014-06-14', y: 10},
    {x: '2014-06-15', y: 15},
    {x: '2014-06-16', y: 30}
  ];

  var dataset = new vis.DataSet(items);
  var options = {
    start: '2014-06-10',
    end: '2014-06-18'
  };
  var graph2d = new vis.Graph2d(container, dataset, options);
*/
