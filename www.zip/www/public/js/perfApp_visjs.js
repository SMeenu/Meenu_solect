var app = angular.module('perfApp', []); 
app.controller("perfCtrl", function ($scope, $http, $timeout, $window, $location) {  
var container = document.getElementById('perfplots');

//$scope.init = function () {                                                 
         $http.get("/nwTest").
		 then( function (results) {
	console.log("Single result value:", results.data.length);	
	//$scope.nodes = new vis.DataSet(results.data); 

	var node = [];
	var latency = [];
	var index = [];
	for (var i = 0; i < 3; i++) {
		//try{
		node.push(results.data[i].ip);
		//}catch{alert("No network connection"); }
		latency.push(results.data[i].latency);
		index.push(5*(i+1));
	}
    var groups = new vis.DataSet();
    groups.add({id: 0, content: "Latency (ms)"})
    groups.add({id: 1, content: "group1"})
    groups.add({id: 2, content: "group2"})
    alert("hello");
   
     var items = [
	//{x: index, y:latency, group:0}
	{x: 'Jan 2', y: latency[0], group:0},
	{x: 'Jan 3', y: latency[1], group:0},
	{x: 'Jan 4', y: latency[2], group:0}
	];
     
	console.log("values are:"+ node);
	console.log("labels:" + index);
        var options = {
        style:'bar',
	//defaultGroup: 'ungrouped',
        legend: true,
        stack:false,
        barChart: {width:20, align:'center', sideBySide:true}, // align: left, center, right
        drawPoints: false,
        /* dataAxis: {
            icons:true
        }, */
        orientation:'top',
	//start: '1',
	//end: '12'
        start: 'Jan 01',
	end: 'Jan 30'
	//start: '2014-06-01',
        //end: '2014-07-30'
    };
    var graph2d = new vis.Graph2d(container, items, groups, options);
    graph2d.addEventListener("scroll", {});	
	//graph2d.off('rangechanged', onChange);
});
});

