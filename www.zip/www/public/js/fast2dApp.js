// JavaScript source code

var app = angular.module('fast2dApp', []);

app.controller("fast2dCtrl", function ($scope, $http, $timeout, $window, $location) {
    $scope.jsonData = null;

    var container = document.getElementById('fast2dgraph');
    var options = {
        width: '100%',
        height: '400px',
        start: 0,
        end: 400, 
        drawPoints: false,
        dataAxis: { showMajorLabels: false },
        format: 
        {
            minorLabels: {
                millisecond: 'ss SSS',
                second: 'ss',
                minute: 's SSS',
                hour: 'HH:mm',
            },
            majorLabels: {
                millisecond: '',
                second: '',
                minute: '',
                hour: '',
                weekday: ' ',
                day: '',
                month: '',
                year: ''
            }
        }
    };

    $scope.init = function () {
        $http.get("/128KHzData").
            then(function (response) {            
            var dataset = new vis.DataSet(response.data);
            $scope.graph2d = new vis.Graph2d(container, dataset, options);
            
        });
    };

    $scope.init();
});