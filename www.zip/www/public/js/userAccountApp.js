// JavaScript source code

angular.module('userAccountApp', ['ui.bootstrap']).controller('userAccountCtrl', function ($scope, $http, $window) {
    //angular.module('userAccountApp', []).controller('userAccountCtrl', function ($scope, $http) {
    $scope.userid = ''; // for add user
    $scope.accessLevel = '';
    $scope.passw1 = '';
    $scope.passw2 = '';
    $scope.edituserid = '';
    $scope.users = [
    ];
    $scope.edit = true;
    $scope.error = false;
    $scope.incomplete = false;
    
    $scope.reset = function () {
        $http.get("/accountmgr/getaccounts").
            then(function (response) {
            //$scope.jsonData = angular.toJson(response.data);
            $scope.users = response.data;
        }, function (response) {
            console.log("response.fail");
        });
    };

    $scope.ok = function () {
        console.log("save:" + $scope.edituserid + "/" + $scope.passw1);
        
        var jdata = 'id=' + $scope.edituserid + "&" + 'passwd=' + $scope.passw1;
        $.post("/accountmgr/changepasswd", jdata,
		    function (data, status) {
        });
        $scope.chPasswdModal = false;
        
        // cleanup after save
        $scope.userid = '';
        $scope.passw1 = '';
        $scope.passw2 = '';
    };
    
    $scope.cancel = function () {
        console.log("cancel");
        $scope.userid = '';
        $scope.passw1 = '';
        $scope.passw2 = '';
        $scope.chPasswdModal = false;
    };
    
    $scope.updatePasswd = function (id) {
        $scope.edit = true;
        $scope.edituserid = id;
        $scope.userid = id;
        $scope.chPasswdModal = true;
        return;
    };
    
    $scope.showAddUser = function () {
        $scope.addUserModal = true;
        return;
    };
    
    $scope.hideAddUser = function () {
        $scope.addUserModal = false;
        return;
    };
    
    $scope.addUser = function (id, passwd) {
        var jdata = 'id=' + id + "&" + 'passwd=' + passwd;
        $.post("/accountmgr/addaccount", jdata,
		    function (data, status) {
            if (data === 'done') {
                alert("account added");
                $scope.userid = $scope.passw1 = $scope.passw2 = '';
                $scope.addUserModal = false;
                $scope.reset();
            }
            else { $window.alert(data); }
        });
    };
    
    $scope.deleteUser = function (id) {
        if ($window.confirm('Are you sure you want to delete the account?')) {
            var jdata = 'id=' + id;
            $.post("/accountmgr/deleteaccount", jdata,
                function (data, status) {
                if (data === 'done') { $scope.reset(); }
                else { $window.alert(data); }
            });
        }
    };
    
    $scope.$watch('passw1', function () { $scope.test(); });
    $scope.$watch('passw2', function () { $scope.test(); });
    //$scope.$watch('userid', function () { $scope.test(); });
    //$scope.$watch('accessLevel', function () { $scope.test(); });
    
    $scope.test = function () {
        if ($scope.passw1 !== $scope.passw2) {
            $scope.error = true;
        } else {
            $scope.error = false;
        }
        $scope.incomplete = false;
        if ($scope.edit && (!$scope.userid.length || $scope.passw1.length < 6 || 
            !$scope.passw1.length || !$scope.passw2.length)) {
            $scope.incomplete = true;
        }
    };
    
    // initalize the jsonData object by calling reset()
    $scope.reset();
});