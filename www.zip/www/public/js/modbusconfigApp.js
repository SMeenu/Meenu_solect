// JavaScript source code

var app = angular.module('npJsonEditorApp', ['json-tree']);

app.controller("npJsonEditorCtrl", function ($scope, $http) {
    $scope.jsonData = {};
  
    $scope.reset = function () {
        $http.get("/getmodbusparams").
            then(function (response) {
                //$scope.jsonData = angular.toJson(response.data);
                $scope.jsonData = response.data;
            }, function (response) {
            console.log("response.fail");
            });
    };
    
    // initalize the jsonData object by calling reset()
    $scope.reset();

    // save jsonData object
    $scope.save = function () {
        var dataObj = {'params' : angular.toJson($scope.jsonData, true)}; // true flag to make it pretty
        
        // dataObj doesn't work, failed to pass dataObj to the server
        if (confirm('Are you sure you want to apply the changes?')) {
            $http.post('/savemodbusparams', dataObj).
            then(function (data) {
                console.log(data);
            } , function (response) {
                console("Error: " + response);
            });
        }
    };
});
