// JavaScript source code

var app = angular.module('ACPowerDataApp', []);

app.controller("ACPowerDataCtrl", function ($scope, $http, $timeout, $window, $location, myserv) {
    $scope.graph2d;
    $scope.x = myserv.protocol();
    $scope.dataset = new vis.DataSet();

    var container = document.getElementById('ACPowergraph');
    var options = {
        width: '100%',
        height: '400px',
        start: 0,
        end: 400, 
        drawPoints: false,
        dataAxis: { showMajorLabels: false },
        shaded: {
            orientation: 'bottom' // top, bottom
        },
        format: 
        {
            minorLabels: {
                millisecond: 'ss SSS',
                second: 'ss',
                minute: 's SSS',
                hour: 'HH:mm',
            },
            majorLabels: {
                millisecond: '',
                second: '',
                minute: '',
                hour: '',
                weekday: ' ',
                day: '',
                month: '',
                year: ''
            }
        }
    };

    $scope.init = function () {
        $scope.graph2d = new vis.Graph2d(container, $scope.dataset, options);
    };
    
    function WebSocketRequest() {
        if ("WebSocket" in window) {
            //console.info('x: ' + $scope.x);       
            // Let us open a web socket
            var url;
            if ($scope.x === 'https:') {
                url = "wss://" + $location.host() + ":" + $location.port();

            } else {
                url = "ws://" + $location.host() + ":" + $location.port();
            }
  
            var ws = new WebSocket(url);
            
            ws.onopen = function () {
                // Web Socket is connected, send data using send()
                ws.send("PowerProduction");
            };
            
            ws.onmessage = function (evt) {
                var data = eval(evt.data);
                $scope.dataset.add(data);

                var range = $scope.graph2d.getWindow();
                var interval = range.end - range.start;
                var now = vis.moment(data[0].x);
                if (now > range.end) { // adjust window
                   $scope.graph2d.setWindow(now - 0.1 * interval, now + 0.9 * interval);
                }

                // remove all data points which are no longer visible
                var range = $scope.graph2d.getWindow();
                var interval = range.end - range.start;
                var oldIds = $scope.dataset.getIds({
                    filter: function (item) {
                        return item.x < range.start - interval;
                    }
                });
                $scope.dataset.remove(oldIds);

                //$scope.y = data[0].x;
                //console.info($scope.x);
                //console.info("Message is received..." + data[0].x + ", end: "+ range.end);
            };
            
            ws.onclose = function () {
                // websocket is closed.
                console.log("Connection is closed...");
            };
        }
            
        else {
            // The browser doesn't support WebSocket
            alert("WebSocket NOT supported by your Browser!");
        }
    }
    //console.info('x: '+$scope.x + ', useL:' + myserv.userLevel());
    $scope.init();
    WebSocketRequest();
});