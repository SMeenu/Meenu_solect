$(function() {

    Morris.Area({
        element: 'morris-area-chart',
        data: [{
            period: '2013 Q1',
            kwh: 2666
        }, {
            period: '2013 Q2',
            kwh: 2778
        }, {
            period: '2013 Q3',
            kwh: 4912
        }, {
            period: '2013 Q4',
            kwh: 3767
        }, {
            period: '2014 Q1',
            kwh: 6810
        }, {
            period: '2014 Q2',
            kwh: 5670
        }, {
            period: '2014 Q3',
            kwh: 4820
        }, {
            period: '2014 Q4',
            kwh: 10073
        }, {
            period: '2015 Q1',
            kwh: 10687
        }, {
            period: '2015 Q2',
            kwh: 8432
        }],
        xkey: 'period',
        ykeys: ['kwh'],
        labels: ['kwh'],
        pointSize: 2,
        hideHover: 'auto',
        resize: true
    });

    Morris.Donut({
        element: 'morris-donut-chart',
        data: [{
            label: "Early Morning",
            value: 12
        }, {
            label: "Daylight",
            value: 30
        }, {
            label: "Night",
            value: 20
        }],
        resize: true
    });

    Morris.Bar({
        element: 'morris-bar-chart',
        data: [{
            y: '2009',
            kwh: 100
        }, {
            y: '2010',
            kwh: 75
        }, {
            y: '2011',
            kwh: 50
        }, {
            y: '2012',
            kwh: 75
        }, {
            y: '2013',
            kwh: 50
        }, {
            y: '2014',
            kwh: 75
        }, {
            y: '2015',
            kwh: 100
        }],
        xkey: 'y',
        ykeys: ['kwh'],
        labels: ['%pct'],
        hideHover: 'auto',
        resize: true
    });

});
