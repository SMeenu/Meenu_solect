var app = angular.module('perfApp', []); 
app.controller("perfCtrl", function () {  
var container = document.getElementById('perfplots');
$.get("/nwTest").                                                  
                 then( function (results) {                                     
        console.log("Result value:", results.length); 
	var results_data = JSON.parse(results);
	console.log("Data:", results_data.ip);
	console.log("1.", results.ip);

        var node = [];                                                          
        var latency = [];                                                       
        var index = [];                                                         
        for (var i = 0; i < 3; i++) {                                           
                //try{                                                          
                node.push(results.data[i].ip);                                  
                //}catch{alert("No network connection"); }                      
                latency.push(results.data[i].latency);                          
                index.push(5*(i+1));                                            
        }                                                                       
                                                                                
        console.log("values are:"+ node);                                       
        console.log("labels:" + index);       
	
});

 Highcharts.chart('perfplots', {
        chart: {
            type: 'column'
        },
        title: {
            text: 'Mesh Network Performance'
        },
        xAxis: {
            categories: [
                'Seattle HQ',
                'San Francisco',
                'Tokyo'
            ]
        },
        yAxis: [{
            min: 0,
            title: {
                text: 'Employees'
            }
        }, {
            title: {
                text: 'Profit (millions)'
            },
            opposite: true
        }],
        legend: {
            shadow: false
        },
        tooltip: {
            shared: true
        },
        plotOptions: {
            column: {
                grouping: false,
                shadow: false,
                borderWidth: 0
            }
        },
        series: [{
            name: 'Employees',
            color: 'rgba(165,170,217,1)',
            data: [150, 73, 20],
            pointPadding: 0.3,
            pointPlacement: -0.2
        }, {
            name: 'Employees Optimized',
            color: 'rgba(126,86,134,.9)',
            data: [140, 90, 40],
            pointPadding: 0.4,
            pointPlacement: -0.2
        }, {
            name: 'Profit',
            color: 'rgba(248,161,63,1)',
            data: [183.6, 178.8, 198.5],
            tooltip: {
                valuePrefix: '$',
                valueSuffix: ' M'
            },
            pointPadding: 0.3,
            pointPlacement: 0.2,
            yAxis: 1
        }, {
            name: 'Profit Optimized',
            color: 'rgba(186,60,61,.9)',
            data: [203.6, 198.8, 208.5],
            tooltip: {
                valuePrefix: '$',
                valueSuffix: ' M'
            },
            pointPadding: 0.4,
            pointPlacement: 0.2,
            yAxis: 1
        }]
    });
});
        /* $http.get("/nwTest").
		 then( function (results) {
	console.log("Single result value:", results.data.length);	
	//$scope.nodes = new vis.DataSet(results.data); 

	var node = [];
	var latency = [];
	var index = [];
	for (var i = 0; i < 3; i++) {
		//try{
		node.push(results.data[i].ip);
		//}catch{alert("No network connection"); }
		latency.push(results.data[i].latency);
		index.push(5*(i+1));
	}
    var groups = new vis.DataSet();
    groups.add({id: 0, content: "Latency (ms)"})
    groups.add({id: 1, content: "group1"})
    groups.add({id: 2, content: "group2"})
    alert("hello");
   
     var items = [
	//{x: index, y:latency, group:0}
	{x: 'Jan 2', y: latency[0], group:0},
	{x: 'Jan 3', y: latency[1], group:0},
	{x: 'Jan 4', y: latency[2], group:0}
	];
     
	console.log("values are:"+ node);
	console.log("labels:" + index);
        var options = {
        style:'bar',
	//defaultGroup: 'ungrouped',
        legend: true,
        stack:false,
        barChart: {width:20, align:'center', sideBySide:true}, // align: left, center, right
        drawPoints: false,
         dataAxis: {
            icons:true
        },
        orientation:'top',
	//start: '1',
	//end: '12'
        start: 'Jan 01',
	end: 'Jan 30'
	//start: '2014-06-01',
        //end: '2014-07-30'
    };
    var graph2d = new vis.Graph2d(container, items, groups, options);
    graph2d.addEventListener("scroll", {});	
	//graph2d.off('rangechanged', onChange);
});
});  */

