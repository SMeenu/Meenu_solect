// JavaScript source code
// power.js

'use strict';
/**
 * Module dependencies.
 * @private
 */

//var pathRegexp = require('path-to-regexp');
//var debug = require('debug')('express:router:layer');

var child_process = require('child_process');
var json_request = require('request');

var jsonServerUrl = "http://localhost:3000"; // should from config 

/**
 * Module exports.
 * @public
 */

module.exports = Power;
function Power(path, options, fn) {
    if (!(this instanceof Power)) {
        return new Power(path, options, fn);
    }

    //debug('new %s', path);
    var opts = options || {};

    this.handle = fn;
    this.name = fn.name || '<anonymous>';
    this.params = undefined;
    this.path = undefined;
    //this.regexp = pathRegexp(path, this.keys = [], opts);

    //if (path === '/' && opts.end === false) {
    //    this.regexp.fast_slash = true;
    //}
}

/**
 * function to set power curtailment to the whole system
 * @param {Response} res: http response object
 * @param {var} powerVar: percent of total power
 * @param {var} osIsLinux: flag for Linux OS
 * @api public
 */
Power.setPowerVar = function setPowerVar(res, powerVar, osIsLinux) {
    if (powerVar > 100) {
        powerVar = 100;
    } else if (powerVar < 0) {
        powerVar = 0;
    }

    if (osIsLinux) {
        var isRunJson = true;
        if (isRunJson) {
            // calling json server
            var data = {
                "request": {
                    "pct": powerVar
                }
            };

            json_request({
                url: jsonServerUrl + "/group_set",
                method: "POST",
                json: true,   // <--Very important!!!
                body: data
            }, function (error, response, replydata) { });
        } else {
            // call the shell cmd directly

            Power.run_cmd('/usr/local/sbin/demo.sh', [powerVar], function (text) {
                console.log(text);
            });

        }
    } else {
        console.log("Windows:set powerVar: " + powerVar);
    }

    res.send("done"); // This is needed, the client is waiting for this
        
    return;
};

// utility function to run a command
Power.run_cmd =  function(cmd, args, callBack) {
    //var spawn = require('child_process').spawn;
    //var spawn = child.spawn;
    var child = child_process.spawn(cmd, args);
    var resp = "";

    child.stdout.on('data', function (buffer) { resp += buffer.toString() });
    child.stdout.on('end', function () { callBack(resp) });
}


//run_cmd("ls", ["-l"], function (text) { console.log(text) });
//run_cmd("hostname", [], function (text) { console.log(text) });

