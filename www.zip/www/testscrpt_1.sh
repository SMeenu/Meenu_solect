# Copyright (c) 2016 by Solectria, A Yashkawa Company. All rights reserved.

# History: 2016-11-15 initial version

# The script identifies neighbors from /etc/solectria/network/network_map.json file
# It is assumed that IP address is stored as the 2nd field in each row
# The script pings each neighboring terminal and estimates the latency and loss percentage
# The upload and download throughput are determined using iperf
# The results are displayed in table format in command line and also stored as key-value pairs in Nw_perf.json file

# Methodology:
# ------------
# An iperf server deamon is waiting in every terminal
# The default port 5001 is having issues with bodirectional address binding. 
# So the iperf server is made to wait in port 13130
# One terminal (probably the gateway) acts as the iperf client and connects with each iperf server running 
# in the available neighbors: This gives the upload throughput
# The download through is determined by reversing the client server roles

# Need to add handler for "Warning: Permanently added '10.15.140.246' (ECDSA) to the list of known hosts"
# Need to add handler for timeout scenario

# Function to restrict the span of each command
# This function avoids the long pause if the connection could not be extablished with the neighbor

# Modes of running:
# 1. Quick (skips throughput computation); Avg span: 7 secs/node
# 2. Extensive (includes throughput computation); Avg span: 25 secs/node - linearly increases with the network size
# This version is silent and not interactive
f_tout () {
        $1 &
        sleep $2
        kill $!
}

function clean_up() {
	rm -r /home/service/logs
	# f_tout 'nohup iperf -s &' 8
	rm status
	exit 0
}

rm -Rf /home/service/logs
rm /home/service/Nw_perf.json 2>/dev/null
mkdir /home/service/logs
x=$(ps -ef | grep 'iperf')
kill $(echo $x |head -n2 | tail -n1 | awk -F " " '{print $2 }') 2> /dev/null

# Array stores the parameter string and calculated value in subsequent positions                                                    
arr=
# Array index
count=0
grep "ipv4" /etc/solectria/network/network_map.json | awk -F ',' '{print $2}' |awk -F ':' '{print $2}' | sed 's,..\(.*\).$,\1,g' > /home/service/logs/f1
n_nodes=$(cat /home/service/logs/f1 | wc -l )
>&2 echo $n_nodes 1>&2
