/**
 * @Copyright (c) 2016 by Solectria, A Yaskawa Company.  All rights reserved.
 * @name modbus.js
 * @author fengjia hu
 * @module -- modbus.js - a nodejs application
 * @description   TLM SunSpec/modbus service prototype code
 */

"use strict";

var modbustcp = require('jsmodbus');
var util = require('util');

// Following  are packages for serial communication
// modbus-rtu
var SerialPort = require('serialport').SerialPort;
var modbusrtu = require('modbus-rtu');
var crc = require('modbus-rtu/node_modules/crc');
var Q = require('q');
var _ = require('modbus-rtu/node_modules/lodash');

// const variables for configuration files
const MODBUS_CONFIG = './config/modbus.json';
const MODBUS_SYS_CONFIG = './config/modbus-sys.json';
const SUNSPEC_DEFINITIONS = './config/SunSpecDefs.json';
const DSP_MAP = './config/DSPMap.json';
const RELEASE_JSON = './config/release.json';

// variables for EOL mode operations
const EOL_MODE_FILE = '/etc/solectria/config.json'
const EOL_REG_OFFSET = 899; // absoulte addr: 30999
var Open_Mode = true;
var EOL_key = [40000, 40003, 40070];
var client_key = [];
var MF_Mode = false; // Manufacturing Mode flag

// 
// load configurations
//
var config = require('./lib/config');
var fs = require('fs');

var modbus_config = JSON.parse(fs.readFileSync(MODBUS_CONFIG));
//var rel_config = JSON.parse(fs.readFileSync(RELEASE_JSON));
var modbus_sys_config = JSON.parse(fs.readFileSync(MODBUS_SYS_CONFIG));

// Arches communication object
var ArchesComm = null;
// 
// create log file
//
var log = function () { };
var log4js = require('log4js');
log4js.configure({
    appenders: [
        {
            type: 'file', filename: 'logs/node.log', "maxLogSize": 32000,
            "backups": 2, category: 'modbus'
        }
    ]
});
log4js.loadAppender('file');
var logger = log4js.getLogger('modbus');

logger.setLevel('FATAL');

if (modbus_config.logger) {
    logger.setLevel('INFO');
   log = logger.info;
}

// following are constant variables
// for SunSpec memory and internal memory
const max_num_registers = 5000; 
const SunSpecMemoryStart = 40000;
const InternalMemoryStart = 30100;
const InternalEOLRegsEnd = 30700;
const SUNSPEC_REGS_FILE = 'SunSpecRegs.dat';
const INTERNAL_REGS_FILE = 'InternalRegs.dat';
//
var backupFlag = false;

const comport = modbus_sys_config.serialport;

var RegisterMemory = new Buffer(max_num_registers * 2); // memory for SunSpec Registers
var InternalRegisters = new Buffer(max_num_registers * 2); // memory for Manufacturing Control Registers

var writeRegSet = new Set();
var DSPMap = new Map();
var DSPWriteMap = new Map();
var DSPCacheQ = [];
var DSPInitRead = [];

//
// save EOL mode to a json file
//
function SetEOLFile(eol_mode) {
    var eol_config = {};
    try {
        eol_config = JSON.parse(fs.readFileSync(EOL_MODE_FILE, 'utf8')); 
    } 
    catch (err) {}
       
    // update the attribute
    eol_config.EOL_Mode = eol_mode; 

    // save to file
    fs.writeFile(EOL_MODE_FILE, JSON.stringify(eol_config), (err) => {
        if (err) console.info(err);
    });
}

// update EOL file with EOL mode
SetEOLFile(MF_Mode);

//
// load DSP map function,
// which maps MODBUS address to DSP internal address
//
function LoadDSPMap() {
    try {
        var dsp_defs = JSON.parse(fs.readFileSync(DSP_MAP, 'utf8'));
        
        for (var i = 0; i < dsp_defs.registers.length; i++) {
            var DSPaction = dsp_defs.registers[i].data_read_write;
            var fmt = dsp_defs.registers[i].fmt;
            var quant = dsp_defs.registers[i].quant;
            var sf_addr = dsp_defs.registers[i].register - dsp_defs.registers[i].offset + dsp_defs.registers[i].data_sf_offset;
            var sf = 0;

            // Get sf from the SunSpec scale factor register
            // sf_offset=0 is no offset
            if (dsp_defs.registers[i].data_sf_offset != 0 && dsp_defs.registers[i].data_sf_offset != undefined) {
 
                var offset = sf_addr - SunSpecMemoryStart;
                sf = RegisterMemory.readInt16BE(offset * 2);
           }

            // DSPaction=0, direct_read
            // DSPaction=1, direct_read, direct_write
            // DSPaction=2, init_cache
            // DSPaction=3, cache_read
            // DSPaction=4, direct_write
            // DSPaction=5, init_rw

            // fmt=1, int16(MODBUS) <-> float(DSP)
            // fmt=2, float(MDOBUS) <-> float(DSP)
            // fmt=0, none of above

            if (fmt===1) {
                quant = 1;
            }
            if (fmt===2) {
                quant = 2;
            }

            // load to DSP direct read map
            if (DSPaction === 0 || DSPaction === 1) {
                var value = {daddr: dsp_defs.registers[i].data_key, fmt: fmt, sf: sf};

                DSPMap.set(dsp_defs.registers[i].register, value);   
            }

            // load to DSP write map
            if(DSPaction === 1 || DSPaction === 4 || DSPaction === 5) {
                var value = {daddr: dsp_defs.registers[i].data_key, fmt: fmt, sf: sf};

                DSPWriteMap.set(dsp_defs.registers[i].register, value);
            }

            // load to DSP Init Read map
            if (DSPaction === 2 || DSPaction === 5) {
                DSPInitRead.push({
                    maddr: dsp_defs.registers[i].register,
                    daddr: dsp_defs.registers[i].data_key,
                    quant: quant,
                    fmt: fmt,
                    sf: sf
                });
            }
        
            // load to DSP cache map
            if (DSPaction === 3) {
                DSPCacheQ.push({
                    maddr: dsp_defs.registers[i].register,
                    daddr: dsp_defs.registers[i].data_key,
                    quant: quant,
                    fmt: fmt,
                    sf: sf
                }); 
            }
        }
        //console.log('DSPMap', DSPMap)
        //console.log('DSPWMap', DSPWriteMap)
        //console.log('DSPInitRead', DSPInitRead)
        //console.log('DSPCacheQ', DSPCacheQ)
    }
    catch (e) {
        logger.info('No DSP Map file');
    }
}

/**
 * function for reading DSP registers
 * @param maddr - Modbus starting address
 * @param quant - quantity of registers
 */
function ReadDSPRegisters(maddr, quant) {
    var deferred = Q.defer();
    
    if (DSPMap.has(maddr)) {
        
        //console.info('readdsp:' + maddr + ", daddr:" + DSPMap.get(maddr));
        var value = DSPMap.get(maddr);
        var daddr = value.daddr;
        var fmt = value.fmt;
        var sf = value.sf;

        //if (fmt === 1) {
        //    quant *= 2;
        //}

        // promise method
        return ArchesComm.readdsp(daddr, quant, fmt, sf).then(function (data) {
            // data.length === quant
            //console.info('arches queue DSP reply:', data, fmt); // data = [ ]
            /*
            var results = [];
            if (fmt === 1) { 
                // fmt==1 => int (MODBUS) <- float (DSP)
                // convert float to int
                const buf = new Buffer(4); 
                for (var i = 0; i < data.length/2; i++) {
                    buf.writeUInt16BE(data[i*2], 0); 
                    buf.writeUInt16BE(data[i*2+1], 2); 

                    var value = buf.readFloatBE(0);
                    if (value < 0) value = 0;

                    results.push(Math.round(value)); 
                }
            } else {
                results = data;
            }
            */

            return data;
            //deffered.resolve(data);
        }, function (err) { 
            // DSP is not responding, timeout
            console.info('readdsp.err', err);
            deffered.reject([]);
        });

    }
    else {
        deferred.reject([]);
    }

    return deferred.promise;
}

/**
 * function for writing DSP registers
 * @param maddr - Modbus starting address
 * @param numberOfBytes - byte count in values
 * @param values - contents for writing to DSP, buf 
 * @param multFlag - flag for Modbus Mutiltpe register write
 */
function WriteDSPRegisters(maddr, numberOfBytes, values, multFlag) {
    var deferred = Q.defer();
    
    //console.log('write DSP check', maddr);
    if (DSPWriteMap.has(maddr)) {
        var item = DSPWriteMap.get(maddr);
        var daddr = item.daddr;
        var fmt = item.fmt; // fmt=1, int(Modbus) -> float(DSP)
        var sf = item.sf;
        //console.log('write dsp:', maddr, item, daddr, fmt, sf);
        
        ArchesComm.writedsp(daddr, values, fmt, sf).then(function (data) { 
            //console.info('write DSP reply:' + data); // data = [ ]
            
            //return data;
            // return in modbus reply format
            var res = []
            var ret = data.shift();
            if (!ret) { 
                res.push(maddr);
                // write success
                if (multFlag) {
                    res.push(numberOfBytes/2)
                } else {
                    res.push(values)
                }
 
            } else {
                res.push(4); // for device failure
            }
            deferred.resolve(res);
        });
    }
    else {
        deferred.reject([]);
    }
    
    return deferred.promise;
}

// Cache all the register write attributes
function InitWRegSet() {
   
    writeRegSet.clear();

    // SunSpec Writable registers
    var sunspec_defs = JSON.parse(fs.readFileSync(SUNSPEC_DEFINITIONS, 'utf8'));
    
    for (var i = 0; i < sunspec_defs.length - 1; i++) { // read DID record
        if (sunspec_defs[i].registers !== undefined) {
            for (var j = 0; j < sunspec_defs[i].registers.length; j++) { // read registers array
                if (sunspec_defs[i].registers[j].read_write === 1) {
                    for (var k = 0; k < sunspec_defs[i].registers[j].size; k++) {
                        //var addr = sunspec_defs[i].registers[j].register + sunspec_defs[i].registers[j].offset + k;
                        var addr = sunspec_defs[i].registers[j].register + k;
                        //if (k === 0) console.info('iw:' + addr)
                        
                        writeRegSet.add(addr);
                    }
                }
            }
        }
    }

    // Internal writable registers
    //if (MF_Mode) {
    {
        // the last record is internal registers attributs
        var i = sunspec_defs.length - 1;
        for (var j = 0; j < sunspec_defs[i].registers.length; j++) { // read WRegs array
            if (sunspec_defs[i].registers[j].read_write === 1) {
                for (var k = 0; k < sunspec_defs[i].registers[j].size; k++) {
                    //var x = sunspec_defs[i].registers[j].register + sunspec_defs[i].registers[j].offset + k;
                    //if (k === 0) console.info('iw:' + x)
                    //writeRegSet.add(sunspec_defs[i].registers[j].register + sunspec_defs[i].registers[j].offset + k);
                    writeRegSet.add(sunspec_defs[i].registers[j].register + k);
                }
            }
        }
    }

    //console.log('sunspecdefs', sunspec_defs.length)
}

//
// return a boolean for read registers permisson for a set of registers
// true: read permitted
// false: read not permitted
//
function CheckRRegPermission(start, quant, fromRS485) {
    var ok = true;

    // EOL Mode of internal registers
    if (start >= InternalMemoryStart && 
            (start + quant) < (InternalEOLRegsEnd)) {
        if (!MF_Mode) { 
            // not (MF_Mode and fromRS485)
            return false;
        }
    }
    
    return ok;
}


//
// return a boolean for write to registers permisson to a set of registers
// true: write permitted
// false: write not allowed
//
function CheckWRegPermission(start, quant, fromRS485) {
    
    // EOL Mode of internal registers
    if (start >= InternalMemoryStart && 
            (start + quant) < (InternalEOLRegsEnd)) {
        if (!MF_Mode || !fromRS485) {
            // not (MF_Mode and fromRS485)
            return false;
        }
    }
    
    //
    // Passed EOL mode check, final registers write attribut check
    //
    var ok = true;
    for (var i = start; i < start + quant; i++) {
        if (!writeRegSet.has(i)) {
            ok = false;
            break;
        }
    }

    return ok;
}

//modbustcp.setLogger(function (msg) { util.log(msg); });
//modbustcp.setLogger(console.info); // to turn on debug info on console

function randomInt(low, high) {
    return Math.floor(Math.random() * (high - low) + low);
}

function LoadRegisters() {
    
    // Load SunSpec registers
    var path = SUNSPEC_REGS_FILE;
    fs.open(path, 'r', function (err, fd) {
        if (err) {
            InitSunSpecRegisterMemory();
            //logger.info('error opening file: ' + err);
        } else {
           fs.read(fd, RegisterMemory, 0, RegisterMemory.length, null, function (err) {
                // update device address
                RegisterMemory.writeUInt16BE(modbus_config.slave_id, 68 * 2); // device address

                if (err) console.log('error reading file: ' + err);
                fs.close(fd, function () {
                    //console.log('file read');
                })
            });
        }
     });
    
    // create random EOL key
    var array = [];
    var key = 0;
    var addr = 30800; // starting base
    for (var i = 0; i < 4; i++) {
        var number = randomInt(0, 16) & 0x0f;
        if (i % 2) {
            addr -= number; 
        }
        else {
            addr += number;
        }
        array.push(addr)
        key = (key << 4) | number;
    }
    EOL_key = array;
    //console.info('key:'+array)

    // Load internal registers
    var path = INTERNAL_REGS_FILE;
    fs.open(path, 'r', function (err, fd) {
        var eol_addr = EOL_REG_OFFSET;
        
        if (err) {
            InitInternalRegisterMemory();
            //logger.info('error opening file: ' + err);
            
            // write the key seed
            InternalRegisters.writeUInt16BE(key, eol_addr * 2 - 2);

            //var state = InternalRegisters.readUInt16BE(eol_addr * 2);
            //console.info('create eol_mode:' + key);

        } else {

           fs.read(fd, InternalRegisters, 0, InternalRegisters.length, null, function (err) {
                if (err) logger.info('error reading file: ' + err);
                
                // write the key seed
                InternalRegisters.writeUInt16BE(key, eol_addr * 2 - 2);

                // make sure it is set to 0
                InternalRegisters.writeUInt16BE(0, eol_addr * 2);
                
                //var state = InternalRegisters.readUInt16BE(eol_addr * 2);
                //console.info('exist eol_state:' + state);

                fs.close(fd, function () {
                    //console.log('file read');
                })
            });
        }
    });
}

function SaveInternalRegistersData() {
    
    var path = INTERNAL_REGS_FILE;
    fs.open(path, 'w', function (err, fd) {
        if (err) {
            throw 'error opening file: ' + err;
        } else {
            
            fs.write(fd, InternalRegisters, 0, InternalRegisters.length, null, function (err) {
                if (err) throw 'error writing file: ' + err;
                fs.close(fd, function () {
                    //console.log('file written');
                })
            });
        }
    });
}

function SaveSunSpecRegistersData() {
    
    var path = SUNSPEC_REGS_FILE;
    fs.open(path, 'w', function (err, fd) {
        if (err) {
            logger.info('error opening file: ' + err);
        } else {

            fs.write(fd, RegisterMemory, 0, RegisterMemory.length, null, function (err) {
                if (err) logger.info('error writing file: ' + err);
                fs.close(fd, function () {
                    //console.log('file written');
                })
            });
        }
    });
}

function UpdateModbusID(slaveid) {
    modbus_config.slave_id = slaveid;
    // save to file
    fs.writeFile(MODBUS_CONFIG, JSON.stringify(modbus_config));
}

const SUNSPEC_MID_ADR = 40068;
const EOL_MODE_ADR = InternalMemoryStart + EOL_REG_OFFSET;
function processWriteRegisters(adr, numberOfRegisters, values) {
    // check for device address update
    if (SUNSPEC_MID_ADR === adr) {
        UpdateModbusID(values.readInt16BE(0));
    }

    //if (CLOSE_DSPPORT_ADR === adr) {
     //   ArchesComm.closeDSPport();
    //    console.info('close dsp port')
    //}
}

function processOpenMode(addr) {
    if (Open_Mode) {
        
        if (client_key.length >= EOL_key.length) {

            Open_Mode = false;
            return;
        }
        
        // check for the first address to set quenue
        if (addr === EOL_key[0] && (client_key.length === 0)) {
            client_key.push(addr)
        }
        else if (client_key.length > 0) {
            client_key.push(addr);
        }
        
        var is_match = (EOL_key.length === client_key.length) && EOL_key.every(function (element, index) {
            return element === client_key[index];
        });

        // EOL Mode matche check
        if (is_match) {
            // turn off open mode
            Open_Mode = false;
            
            // set to EOL mode
            MF_Mode = true;
            SetEOLFile(MF_Mode);
            
            // set the register as well
            InternalRegisters.writeUInt16BE(1, EOL_REG_OFFSET * 2);
            
            // log it
            logger.info('EOL Mode:' + MF_Mode)
        }
    }
}

function InitSunSpecRegisterMemory() {
    
    // initialize the memory
    RegisterMemory.fill(0);

    var offset = 0; // 40000
    RegisterMemory.write('SunS', offset * 2, 4);
    offset += 2;
    
    var sunspec_defs = JSON.parse(fs.readFileSync(SUNSPEC_DEFINITIONS, 'utf8'));
    
    //
    // skip the first record, it is SunSpec header
    // and skip the last record, it is internal registers definistions
    //
    for (var i = 1; i < sunspec_defs.length-1; i++) {
        //console.info('DID:' + sunspec_defs[i].DID + ', size:' + sunspec_defs[i].ModelSize + ', addr,' + offset);
        if (sunspec_defs[i].DID === undefined) {
            // Internal registers or other registers
            continue;
        }

        // header
        RegisterMemory.writeUInt16BE(sunspec_defs[i].DID, offset * 2);
        offset += 1;
        RegisterMemory.writeUInt16BE(sunspec_defs[i].ModelSize - 2, offset * 2);
        offset += sunspec_defs[i].ModelSize - 1;

        // set value of registers for the DID
        if (sunspec_defs[i].registers !== undefined) {
            for (var j = 2; j < sunspec_defs[i].registers.length; j++) { // read registers array
                if (sunspec_defs[i].registers[j].value !== "") {
                    // write the value to memory
                    //var addr = sunspec_defs[i].registers[j].register + sunspec_defs[i].registers[j].offset - 40000;
                    var addr = sunspec_defs[i].registers[j].register - 40000;
                    var size = sunspec_defs[i].registers[j].size;
                    var type = sunspec_defs[i].registers[j].type;

                    if (type === "string") {
                        RegisterMemory.write(sunspec_defs[i].registers[j].value, addr * 2, size*2, 'utf8');
                    } else if (type === 'uint16' || type === 'enum16' || type === 'count') {
                        var value = parseInt(sunspec_defs[i].registers[j].value);
                        RegisterMemory.writeUInt16BE(value, addr * 2);
                    } else if (type === 'int16' || type === 'sunssf') {
                        var value = parseInt(sunspec_defs[i].registers[j].value);
                        RegisterMemory.writeInt16BE(value, addr * 2);
                    }
       
                }
            }
        }
    }

    RegisterMemory.writeUInt16BE(0xffff, offset * 2);

    // DSP need get SunSpec data
    LoadDSPMap();
    
    /*
    // setup the common data
    offset = 4; // 40004
    //RegisterMemory.write(rel_config.manufacture, offset * 2, 16, 'utf8'); // default is utf8
    
    offset += 16;
    RegisterMemory.write(rel_config.model, offset * 2, 16, 'ascii'); // default is utf8
    
    offset += 16;
    RegisterMemory.write(rel_config.options, offset * 2, 8, 'ascii'); // default is utf8
    
    offset += 8;
    RegisterMemory.write(rel_config.version, offset * 2, 8, 'ascii'); // default is utf8
    
    offset += 8;
    RegisterMemory.write(rel_config.serial_number, offset * 2, 16, 'ascii'); // default is utf8
   */ 
    offset = 68; // 40068
    RegisterMemory.writeUInt16BE(modbus_config.slave_id, offset * 2); // device address   
    

    //console.log('Memory:' + RegisterMemory);
}

function InitInternalRegisterMemory() {
    InternalRegisters.fill(0);

    // set initial MF_Mode in internal registers
    //var eol_addr = EOL_REG_OFFSET; 
    
    //InternalRegisters.writeUInt16BE(1, eol_addr*2);

    //var quant = max_num_registers;
    //for (var i = 0; i <  quant; i++) {
    //    
    //    InternalRegisters.writeUInt16BE(i+100, i * 2);
    //}
}


LoadRegisters();
InitWRegSet();

var readCoils = function (start, quant) {

    var resp = [];
    for (var i = 0; i < quant; i += 1) {
        resp.push(Math.random()>.5? true: false);
    }

    return [resp];

};
var count = 0;

/**
 * function for reading registers from TCP connection
 * @param adr - Modbus starting address
 * @param quant - quantity of registers
 */
var readInputHoldingRegHandlerTCP = function (adr, quant, modbustcpserver) {
    //return readInputHoldingRegHandler(adr, quant, true);

    // check for read permission
    if (!CheckRRegPermission(adr, quant, false)) {

        modbustcpserver.SendReply([0]);

        return;
    }

    ReadDSPRegisters(adr, quant).then(function (results) {
        
        // send DSP resp as reply
        if (results.length === quant) {
            // send DSP resp as reply    
            modbustcpserver.SendReply([results]); // make results a single element of array
        } else {
            //var resObj = readInputHoldingRegHandler(adr, quant);
            
            modbustcpserver.SendReply([[]]);
        }
    }, function (err) {
        // not part of DSP registers, read from memory
        var resObj = readInputHoldingRegHandler(adr, quant);
        
        modbustcpserver.SendReply(resObj);
    });
}

/**
 * function for reading registers from RS485 connection
 * @param adr - Modbus starting address
 * @param quant - quantity of registers
 */
var readInputHoldingRegHandlerRS485 = function (adr, quant) {
    // check for read permission
    if (!CheckRRegPermission(adr, quant, true)) {
        modbus_rs485.SendReply([[]]);

        return;
    }
    
    processOpenMode(adr);

    // Update with DSP contents
    ReadDSPRegisters(adr, quant).then(function (results) {

        if (results.length === quant) {
            // send DSP resp as reply    
            modbus_rs485.SendReply([results]); // make results a single element of array
        } else {
            //var resObj = readInputHoldingRegHandler(adr, quant);
        
            modbus_rs485.SendReply([[]]);
        }
    }, function (err) {
        // not part of DSP registers, read from memory
        var resObj = readInputHoldingRegHandler(adr, quant);
        
        //console.info("DSP reject reply:" + resObj);
        
        modbus_rs485.SendReply(resObj);
    });

    //return readInputHoldingRegHandler(adr, quant, false);
}

/**
 * function for write registers from RS485 connection
 * @param adr - Modbus starting address
 * @param quant - quantity of registers
 * @param numberOfBytes - number of bytes in values
 * @param values - values to wirte to registers
 */
var writeMultipleRegistersRS485 = function (adr, quant, numberOfBytes, values) {
    if (!CheckWRegPermission(adr, numberOfBytes / 2, true)) {
        modbus_rs485.SendReply([2]);// return error code: 02 for not writable register
        return;
    }
    
    // Update with DSP contents 
    WriteDSPRegisters(adr, numberOfBytes, values, true).then(function (resp) {
        // send DSP resp as reply
        var resObj = writeMultipleRegisters(adr, quant, numberOfBytes, values);
        //console.info('write dsp resp:' + resp);
        
        modbus_rs485.SendReply(resp);
    }, function (err) {
        // not part of DSP registers, write memory
        var resObj = writeMultipleRegisters(adr, quant, numberOfBytes, values);
        
        modbus_rs485.SendReply(resObj);
    });
}

/**
 * function for write single register from RS485 connection
 * @param addr - Modbus starting address
 * @param value - content to write
 */
var writeSingleRegisterRS485 = function (adr, value) {
    if (!CheckWRegPermission(adr, 1, true)) {
        modbus_rs485.SendReply([2]);// return error code: 02 for not writable register
        return;
    }
    
    // Update with DSP contents 
    var buf  = new Buffer(2);
    buf.writeUInt16BE(value, 0);
    WriteDSPRegisters(adr, 2, buf, false).then(function (resp) {
        // send DSP resp as reply
        var resObj = writeSingleRegister(adr, value);
        
        modbus_rs485.SendReply(resp);
    }, function (err) {
        // not part of DSP registers, write to cache memory
        var resObj = writeSingleRegister(adr, value);
        
        modbus_rs485.SendReply(resObj);
    });
}

var writeMultipleRegistersTCP = function (adr, quant, numberOfBytes, value, modbustcpserver) {
    if (!CheckWRegPermission(adr, numberOfBytes / 2, false)) {
        modbustcpserver.SendReply([2]);// return error code: 02 for not writable register
        return;
    }

    // Update with DSP contents 
    WriteDSPRegisters(adr, numberOfBytes, value, true).then(function (resp) {
        // send DSP resp as reply
        var resObj = writeMultipleRegisters(adr, quant, numberOfBytes, value);
        
        modbustcpserver.SendReply(resp);
    }, function (err) {
        // not part of DSP registers, write memory
        var resObj = writeMultipleRegisters(adr, quant, numberOfBytes, value);
        
        modbustcpserver.SendReply(resObj);
    });
}

var writeSingleRegisterTCP = function (adr, value, modbustcpserver) {
    if (!CheckWRegPermission(adr, 1, false)) {
        modbustcpserver.SendReply([2]);// return error code: 02 for not writable register
        return; 
    }
    // Write DSP register 
    var buf  = new Buffer(2);
    buf.writeUInt16BE(value, 0);
    WriteDSPRegisters(adr, 2, buf, false).then(function (resp) {
        // send DSP resp as reply
        var resObj = writeSingleRegister(adr, value);
        
        modbustcpserver.SendReply(resp);
    }, function (err) {
        // not part of DSP registers, write to cache memory
        var resObj = writeSingleRegister(adr, value);
        
        modbustcpserver.SendReply(resObj);
    });
}

//
//var readInputHoldingRegHandler = function (adr, quant) {
function readInputHoldingRegHandler(adr, quant) {
    //console.log('function 3');
    //console.log("start:" + adr + ", quant:" + quant);
    logger.info('fc: 3, start:' + adr + ', quant: ' + quant);
   
    var resp = [];

    var offset = 0;
    if ((adr >= InternalMemoryStart) &&
        (adr + quant) < (InternalMemoryStart + max_num_registers)) {
 
        offset = adr - InternalMemoryStart;
        for (var i = 0; i < quant; i++) {
            var value = InternalRegisters.readUInt16BE((offset + i) * 2);
            //console.log('value ' + i +': ' + value);
            resp.push(value);
        }
       
    } else if (adr >= SunSpecMemoryStart && (adr+quant) < (SunSpecMemoryStart + max_num_registers)) {
        
        offset = adr - SunSpecMemoryStart;
        for (var i = 0; i < quant; i++) {
            var value = RegisterMemory.readUInt16BE((offset + i) * 2);
            //console.log('value ' + i +': ' + value);
            resp.push(value);
        }

    } else {

        //for (var i = 0; i < quant; i++) {
        //    resp.push(0);
        //}
    }
    
    //console.info('data:' + resp);
    return [resp];
}

var readInputRegHandler = function (start, quant) {
    var resp = [];
    
    // outside support register scopes
    if (start < 40000 || start > 40000 + max_num_registers) {
        for (var i = 0; i < quant; i++) {
            resp.push(0);
        }
        return [resp];
    }
    var offset = start - 40000;
    for (var i = 0; i < quant; i++) {
        var value = RegisterMemory.readUInt16BE((offset + i) * 2);
        //console.log('value ' + i +': ' + value);
        resp.push(value);
    }

    return [resp];
}

var writeSingleCoil = function (adr, value) {

    //console.log('write single coil (' + adr + ', ' + value + ')');

    return [];

};

/*
 * @param adr - register address
 * @param value - unsigned integer
 */
var writeSingleRegister = function (adr, value) {

    //console.log('write single register (' + adr + ', ' + value + ')');
    logger.info('fc: 6, start:' + adr + ', value: ' + value);
    
    //if (!CheckWRegPermission(adr, 1)) {    
    //    return [2]; // return error code: 02 for not writable register
    //}
    backupFlag = true;

    var offset = 0;
    if (adr >= InternalMemoryStart && adr < (InternalMemoryStart + max_num_registers)) {

        offset = adr - InternalMemoryStart;
        InternalRegisters.writeUInt16BE(value, offset * 2);

        processWriteRegisters(adr, 1, value);

    } else if (adr >= SunSpecMemoryStart && adr < (SunSpecMemoryStart + max_num_registers)) {

        offset = adr - SunSpecMemoryStart;
        RegisterMemory.writeUInt16BE(value, offset * 2);
   
        processWriteRegisters(adr, 1, value);

   } else {
        return [2]; // return error code: 02 for illegal data address       
    }

    return [adr, value];
};

/**
 * @param values - big endian values in binary buffer
 */
var writeMultipleRegisters = function (firstRegisterAddress, numberOfRegisters, numberOfBytes, values) {
    
    //console.log('write Multiple register (' + firstRegisterAddress + ', ' + numberOfRegisters + ',' + numberOfBytes + ')');
    logger.info('fc: 16, start:' + firstRegisterAddress + ', num registers: ' + numberOfRegisters);

    backupFlag = true;

    var offset = 0;     

    if (firstRegisterAddress >= InternalMemoryStart && 
        (firstRegisterAddress + numberOfBytes / 2) < (InternalMemoryStart + max_num_registers)) {
        
        offset = firstRegisterAddress - InternalMemoryStart;
        values.copy(InternalRegisters, offset * 2, 0, numberOfBytes);
        
        processWriteRegisters(firstRegisterAddress, numberOfRegisters, values);

    } else if (firstRegisterAddress >= SunSpecMemoryStart && 
        (firstRegisterAddress + numberOfBytes / 2) < (SunSpecMemoryStart + max_num_registers)) {
        
        offset = firstRegisterAddress - SunSpecMemoryStart;
        values.copy(RegisterMemory, offset * 2, 0, numberOfBytes);
        
        processWriteRegisters(firstRegisterAddress, numberOfRegisters, values);

    } else {
        return [2]; // return error code: 02 for illegal data address       
    }

    /*
    for (var i = 0; i < numberOfRegisters; i++) {
        //offset += i;    
        var value = values.readInt16BE(i*2);
        console.log("value: " + value);

        //RegisterMemory.writeUInt16BE(value, (offset + i) * 2); 

    }
     * */
     
    return [firstRegisterAddress, numberOfRegisters];
};


var port = modbus_config.tcpip_port;
var ip = null; //'127.0.0.1';

modbustcp.createTCPServer(port, ip, function (err, server) {

    if (err) {
        logger.info(err);
        return;
    }

    //server.addHandler(1, readCoils);
    server.addHandler(3, readInputHoldingRegHandlerTCP); // func:3 read holding register
    //server.addHandler(4, readInputRegHandler);
    //server.addHandler(5, writeSingleCoil);
    server.addHandler(6, writeSingleRegisterTCP);
    server.addHandler(16, writeMultipleRegistersTCP);

});

logger.log("ip port:" + port);
logger.info("slave id:" + modbus_config.slave_id);
logger.info("serial port:" + comport);
logger.info("baud:" + modbus_config.baudrate);

var serialPort = new SerialPort(comport,{
    baudrate: modbus_config.baudrate,
    dataBits: 8,
    stopBits: 1,
    rtscts: true,
    parity: 'none'
}, true, function (err) { if (err) console.log('serialport callback: '+err); });

var slaveid = modbus_config.slave_id;

var slaveError = function (error) {
    logger.info(error);
}
var modbus_rs485 = new modbusrtu.Slave(serialPort, slaveid, function (slave) {
    //console.log("Slave ready");
    //serialPort.open(function (error) { console.log('failed to open' + error); });
    
    //slave.addHandler(1, readCoils);
    slave.addHandler(3, readInputHoldingRegHandlerRS485); // func:3 read holding register
    //slave.addHandler(4, readInputRegHandler);
    slave.addHandler(6, writeSingleRegisterRS485);
    slave.addHandler(16, writeMultipleRegistersRS485);
}, slaveError);

serialPort.on('error', function (error) {
    logger.info("error:" + error);
});

serialPort.on('close', function () {
    logger.info("close:" );
});

var DSPCacheUpdate = function (readQ) {
    
    var promise_chain = Q.fcall(function () { });
    readQ.forEach(function (rdata) {
        var promise_link = function () {
            //console.info('Send request:' + rdata.maddr + ", " + rdata.quant);
            var deferred = Q.defer();
            
             ArchesComm.readdsp(rdata.daddr, rdata.quant, rdata.fmt, rdata.sf).then(function (data) { // this is callback
                //console.info('rece reply:' + rdata.maddr + ", " + rdata.quant);
                
                if (0 === data.length) { // error
                    logger.info('error');
                    deferred.reject();
                }
                else {
                    //console.info('DSP reply:', data); // data = [ ]
                    if (rdata.maddr >= SunSpecMemoryStart) {
                        var offset = rdata.maddr-SunSpecMemoryStart;   

                        for (var i = 0; i < data.length; i++) {
                            //offset += i;
                            var value = data[i];
                            //console.log("value: ", value);

                            RegisterMemory.writeUInt16BE(value, (offset + i) * 2); 
                        }
                    } else {
                        // Internal registers
                        var offset = rdata.maddr-InternalMemoryStart;   

                        for (var i = 0; i < data.length; i++) {
                            //offset += i;
                            var value = data[i];
                            //console.log("value: ", value);

                            InternalRegisters.writeUInt16BE(value, (offset + i) * 2); 
                        }
                    }

                    // update to memory
                    deferred.resolve(data);
                }
            });
            
            return deferred.promise;
        };
        
        promise_chain = promise_chain.then(promise_link);
    });
    
    return promise_chain;
}

var RefashRate = 30000;
function DoOnceCache() {
    DSPCacheUpdate(DSPInitRead).then(function() {
        setTimeout(routineTasks, 1);    
    });
}

function routineTasks() {
    DSPCacheUpdate(DSPCacheQ).then(function () {

        setTimeout(routineTasks, RefashRate);    

    }, function(err) {
        logger.info('DSPCache refresh', err);
        setTimeout(routineTasks, RefashRate);    
    });
 
    if (backupFlag) {
        //SaveInternalRegistersData();
        //SaveSunSpecRegistersData();
        backupFlag = false;
    }
}

// set open mode for 5 minutes
const OPEN_TIME=300000; // n*60*1000
setTimeout(function () { Open_Mode = false;}, OPEN_TIME);

process.on("SIGTERM", function () {
    logger.info('Exit');
    routineTasks();

    process.exit();
});

// DSP communication
var dsp_dev = '/dev/ttyACM';

// find the USB serial port
for (var i = 0; i < 3; i++) {
    var tmp = dsp_dev + i.toString();
    console.log(tmp);
    try {
        fs.accessSync(tmp);
        dsp_dev = tmp;
        break;
    } catch (err) {
        //console.log('no device:'+ tmp)
    }
}

logger.info('DSP port: ' + dsp_dev);

//var dsp_dev = 'COM7';
/*
var dspPort = new SerialPort(dsp_dev, {
    baudrate: 115200,
    dataBits: 8,
    stopBits: 1,
    parity: 'none'
}, false, function (err) { if (err) console.log('dsp port callback: ' + err); });
*/
ArchesComm = new modbusrtu.Arches(dsp_dev, function (dsp) {
    // onReady
    logger.info('Init DSP object: onReady');

    // start DSPCacheUpdate, needs a longer time?
    setTimeout(DoOnceCache, 1000);

    //DSPComm = dsp;
}, function (dspevent) {
    // onEvent
    console.info('DSP event: ' + dspevent);
});

// set routine tasks handler
//setInterval(routineTasks, 10000);

//serialPort.open(function (error) { console.log('failed to open' + error); });


//create ModbusMaster instance and feed them serial port 
/*
new modbusrtu.Master(serialPort, function (master) {
    console.log("Master onReady");
    
    //Read from slave with address 1 four holding registers starting from 0. 
    //master.readHoldingRegisters(1, 40000, 3).then(function (data) {
        //promise will be fulfilled with parsed data 
        //console.log(data); //output will be [10, 100, 110, 50] (numbers just for example) 
    //}, function (err) {
        //or will be rejected with error 
        //for example timeout error or crc. 
    
    //})
     
 
    //master.readHoldingRegisters(1, 40003, 1); // length of module 1
    //master.readHoldingRegisters(1, 40070, 1);
    //master.readHoldingRegisters(1, 40071, 1); // length of module 102
    //master.readHoldingRegisters(1, 40122, 1);

    //Write to first slave into second register value 150. 
    //slave, register, value 
    //master.writeSingleRegister(1, 2, 150).then(success, error);
    //master.writeSingleRegister(1, 2, 150).then(function (success) {
    //    console.log(success);
    //}, function (err) {

     //   })
})
 * */


//var buff = new Buffer([0x02, 0x06, 0x02, 0x4b, 0x00, 0x50, 0xf8, 0x6b]);
//console.assert(crc.crc16modbus(buff) == 0);